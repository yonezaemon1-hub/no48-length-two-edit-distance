# No.48 — Prior-art review, Pass 2 (2026-11-01)

Status: **PARTIAL; NOVELTY INCONCLUSIVE; RELEASE HOLD**. The search did not identify a direct statement of D_2(2)=6/5, D_3(2)=17/14, D_4(2)=123/101, or strict D_5(2)>D_4(2), but a failed search does not establish priority. See URL list below.

## Definition match that matters

This manuscript fixes the *maximum string length at two*, includes the empty string, uses unit-cost insertion/deletion/substitution (ordinary Levenshtein distance), and asks for the **least distortion into an arbitrary real l1 space**, when alphabet size q varies. This is not the same as embedding strings into another string edit metric, the indel-only distance, or the word-length-d -> infinity asymptotic problem.

## Sources and comparison

1. **OpenAI Math family 099**, *Edit Distance in l1: Matching Bounds up to Constants in the Exponent* (2026-09-27). Its stated theorems give exponential-scale asymptotic bounds for sufficiently large maximum word length d, uniformly over finite alphabets. **Same metric and target, different regime and precision**. Its public Lean scope also refers to the word-length asymptotics, not the exact d=2 constants. This checks the main repository scope but not every possible supplemental observation/appendix.
   - https://github.com/openai/math/tree/main/preprints/Edit-Distance-in-l1-Matching-Bounds-up-to-Constants-in-the-Exponent-September-27-2026
   - https://github.com/openai/math/blob/main/lean/docs/099.md
   - https://github.com/openai/math/blob/main/overview.tex

2. **Ostrovsky & Rabani**, *Low Distortion Embeddings for Edit Distance*, Journal of the ACM 54(5), article 23 (2007). DOI 10.1145/1284320.1284322. Develops general embeddings with asymptotic performance on long strings; no d=2 exact constants identified in the accessible abstract. **Related methods; not confirmed duplicate.**
   - https://cris.huji.ac.il/en/publications/low-distortion-embeddings-for-edit-distance-13/

3. **Bhattacharya, Dey, Goldenberg & Koucký**, *Many Flavors of Edit Distance*, FSTTCS 2024, DOI 10.4230/LIPIcs.FSTTCS.2024.11. Studies relationships between edit, indel distance and alphabet-reduction/string-encoding transformations. **Alphabet-size relevance, but the maps and target metric differ from optimal l1 distortion on the entire d=2 space.** Direct exact constants not identified in the publisher summary. Do not equate their alphabet reduction theorem with D_q(2).
   - https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.FSTTCS.2024.11
   - https://arxiv.org/abs/2410.09877

4. **Avis & Deza**, *The cut cone, L1 embeddability, complexity, and multicommodity flows* (1990; Networks 1991/1992), and **Deza & Laurent**, *Geometry of Cuts and Metrics* (1997). Describe the generic cut-cone equivalence underlying our LP and certificates. **Cut decomposition and LP method are established prior art; the potential novelty must rest on the metric-specific constants and strict alphabet dependence.**
   - https://explore.openaire.eu/search/publication?pid=10.1002%2Fnet.3230210602
   - https://link.springer.com/book/10.1007/978-3-642-04295-9

5. **Khot–Naor and later l1 edit-distance lower bounds**; e.g. *Improved Lower Bounds for Embeddings into L1*. Long-string growth of distortion, not a direct d=2 constant calculation in the accessible abstract. **Background, not direct priority proof.**
   - https://epubs.siam.org/doi/10.1137/060660126

## Targeted duplication searches

Searched combinations of: “Levenshtein length-two words l1 distortion cut cone”, “finite alphabet edit distance l1 exact”, “123/101 edit distance”, “785/643 distortion”, “17/14 Levenshtein l1”, “6/5 edit distance l1”, “small string edit metric embedding”. No clearly matching finite-word-length-two exact table was found in the returned accessible records. Numerical queries are weak negative evidence: papers may state equivalent results in decimals, unindexed appendices, or different normalization.

## Unresolved before release

- Search additional specialised metric-embedding and combinatorial-optimization papers for named isometric copies / facets of the cut cone, alternative metric names, and bounds implicit in known facet inequalities.
- Inspect full text and appendices of close works beyond abstracts; particularly check any computational tables and software supplements.
- Request a qualified independent review of the combinatorial finite enumeration, exact LP certificates, and legal/priority wording.
- Check whether the precise constants are in dissertations, software repositories, unpublished notes or databases omitted by the search engine.

**Decision:** Novelty **INCONCLUSIVE**, references **PARTIAL**, submission/release **HOLD**. No inference of originality from lack of search hits.
