#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -I code/verify_hashes.py
python3 -I code/verify_small.py
python3 -I code/verify_exact.py
python3 -I code/verify_q5_certificate.py
if ! command -v g++ >/dev/null 2>&1; then
 echo 'FAIL: g++ C++17 compiler is required for the full exhaustive audit' >&2
 exit 2
fi
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
g++ -O3 -std=c++17 code/enumerate_cuts.cpp -o "$TMP/cuts"
g++ -O3 -std=c++17 code/enumerate_tight_bridge.cpp -o "$TMP/bridge"
g++ -O3 -std=c++17 code/audit_q5_ST.cpp -o "$TMP/scan"
"$TMP/cuts" evidence/pairs_q4.txt "$TMP/cuts_q4.csv"
cmp evidence/cuts_q4.csv "$TMP/cuts_q4.csv"
"$TMP/bridge" evidence/q4_slack_edges.txt "$TMP/q4_tight_masks.txt" "$TMP/q5_compatible_masks.txt"
cmp evidence/q4_tight_masks.txt "$TMP/q4_tight_masks.txt"
cmp evidence/q5_compatible_masks.txt "$TMP/q5_compatible_masks.txt"
"$TMP/scan" evidence/q5_ST_edges.txt "$TMP/q5_ST_scan.txt"
cmp evidence/q5_ST_scan.txt "$TMP/q5_ST_scan.txt"
echo 'PASS COMPLETE: exact LP certificates, 1,048,576 q4 cuts, 58,720,256 q5 canonical cases, manifest'
