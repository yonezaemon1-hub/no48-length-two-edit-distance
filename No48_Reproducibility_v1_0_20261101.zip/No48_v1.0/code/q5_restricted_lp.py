#!/usr/bin/env python3
"""Solve LP restricted to q5 cuts whose every q4 restriction is q4-dual tight."""
import json, pathlib,itertools
from collections import defaultdict
from fractions import Fraction as F
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix,hstack,vstack
P=pathlib.Path(__file__).resolve().parents[1]
q=5
words=[()] + [(a,) for a in range(q)] + [(a,b) for a in range(q) for b in range(q)]
idx={w:i for i,w in enumerate(words)}

def edit(a,b):
 d=list(range(len(b)+1))
 for i,x in enumerate(a,1):
  nd=[i]+[0]*len(b)
  for j,y in enumerate(b,1):nd[j]=min(nd[j-1]+1,d[j]+1,d[j-1]+(x!=y))
  d=nd
 return d[-1]
perms=list(itertools.permutations(range(q)))
classes=defaultdict(list)
for i in range(len(words)):
 for j in range(i+1,len(words)):
  root=min(tuple(sorted((idx[tuple(p[x] for x in (words[i][::-1] if rv else words[i]))],idx[tuple(p[x] for x in (words[j][::-1] if rv else words[j]))]))) for p in perms for rv in (False,True))
  classes[root].append((i,j))
keys=sorted(classes)
assert len(keys)==15,len(keys)
orb=[{'root':list(k),'count':len(classes[k]),'distance':edit(words[k[0]],words[k[1]]),'pairs':[list(z) for z in classes[k]]} for k in keys]
(P/'evidence/q5_orbits.json').write_text(json.dumps({'q':5,'words':[list(w) for w in words],'pair_orbits':orb},indent=2)+'\n')
masks=[int(s.strip()) for s in (P/'evidence/q5_compatible_masks.txt').read_text().splitlines()]
signatures=[]
for m in masks:
 signatures.append(tuple(sum((((m>>a)^(m>>b))&1) for a,b in classes[k]) for k in keys))
uniq=list(dict.fromkeys(signatures))
print('columns',len(uniq),'tight masks',len(masks))
counts=np.array([o['count'] for o in orb],dtype=float)
d=np.array([o['distance'] for o in orb],dtype=float)
B=np.array(uniq,dtype=float).T
A=B/counts[:,None]
n=A.shape[1]
mat=vstack([hstack([-csr_matrix(A),csr_matrix((15,1))]),hstack([csr_matrix(A),csr_matrix(-d[:,None])])])
r=linprog(np.r_[np.zeros(n),1.],A_ub=mat,b_ub=np.r_[-d,np.zeros(15)],bounds=[(0,None)]*n+[(1,None)],method='highs')
print('LP',r.success,r.fun,r.message)
if r.success:
 print('dual', [(i,str(F(float(-v)).limit_denominator(1000000))) for i,v in enumerate(r.ineqlin.marginals) if v<-1e-7])
 print('primal support',[(i,str(F(float(x)).limit_denominator(1000000))) for i,x in enumerate(r.x[:-1]) if x>1e-7])
 (P/'evidence/q5_restricted_lp.json').write_text(json.dumps({'opt':r.fun,'dual':{str(i):str(F(float(-v)).limit_denominator(1000000)) for i,v in enumerate(r.ineqlin.marginals) if v<-1e-7},'primal':{str(i):str(F(float(x)).limit_denominator(1000000)) for i,x in enumerate(r.x[:-1]) if x>1e-7}},indent=2)+'\n')
