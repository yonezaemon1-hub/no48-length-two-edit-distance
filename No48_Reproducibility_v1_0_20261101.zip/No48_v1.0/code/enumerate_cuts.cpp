// Build: g++ -O3 -std=c++17 code/enumerate_cuts.cpp -o enumerate_cuts
// Run from package root: ./enumerate_cuts evidence/pairs_q4.txt evidence/cuts_q4.csv
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>
using Sig=std::array<uint16_t,15>;
struct Hash { size_t operator()(Sig const &s) const {uint64_t h=1469598103934665603ULL;for(auto x:s){h^=x;h*=1099511628211ULL;}return (size_t)h;} };
struct Pair {uint8_t i,j,o;};
int main(int argc,char**argv){
 if(argc!=3){std::cerr<<"usage: enumerate_cuts pairs.txt cuts.csv\n";return 2;}
 std::ifstream in(argv[1]); std::vector<Pair> pairs;int o,i,j;
 while(in>>o>>i>>j){ if(o<0||o>=15||i<0||i>=21||j<0||j>=21)return 3; pairs.push_back({(uint8_t)i,(uint8_t)j,(uint8_t)o}); }
 if(pairs.size()!=210){std::cerr<<"expected 210 pair rows\n";return 4;}
 std::unordered_map<Sig,uint32_t,Hash> unique; unique.reserve(20000);
 for(uint32_t m=0;m<(1u<<20);++m){
   uint32_t full=m<<1; // empty word bit is fixed to zero; complements give same cut distance
   Sig s{};
   for(auto const& p:pairs) s[p.o]+= ((full>>p.i)^(full>>p.j))&1u;
   unique.emplace(s,full);
 }
 std::vector<std::pair<uint32_t,Sig>> sorted;sorted.reserve(unique.size());
 for(auto const& kv:unique)sorted.push_back({kv.second,kv.first});
 std::sort(sorted.begin(),sorted.end(),[](auto const& a,auto const& b){return a.first<b.first;});
 std::ofstream out(argv[2]);out<<"mask";for(int t=0;t<15;t++)out<<",b"<<t;out<<"\n";
 for(auto const& kv:sorted){out<<kv.first; for(auto x:kv.second)out<<","<<x;out<<"\n";}
 std::cerr<<"all masks: "<<(1u<<20)<<" unique signatures: "<<unique.size()<<"\n";
 return 0;
}
