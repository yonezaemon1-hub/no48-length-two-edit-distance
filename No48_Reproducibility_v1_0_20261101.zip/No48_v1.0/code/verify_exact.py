#!/usr/bin/env python3
"""Pure-stdlib verifier for rational q4 primal and dual certificates.
Recomputes edit distances and cut signatures independently from stored orbit data.
For an independent enumeration, regenerate cuts_q4.csv with enumerate_cuts.cpp.
"""
from fractions import Fraction as F
from collections import Counter
import csv, json,pathlib,sys,itertools
P=pathlib.Path(__file__).resolve().parents[1]
cert=json.loads((P/'evidence/q4_exact_certificate.json').read_text())
orb=json.loads((P/'evidence/orbits_q4.json').read_text())
words=[tuple(w) for w in orb['words']]
assert len(words)==21

def edit(a,b):
 dp=list(range(len(b)+1))
 for i,x in enumerate(a,1):
  n=[i]+[0]*len(b)
  for j,y in enumerate(b,1):n[j]=min(n[j-1]+1,dp[j]+1,dp[j-1]+(x!=y))
  dp=n
 return dp[-1]
all_pairs=[]
for z,o in enumerate(orb['pair_orbits']):
 assert len(o['pairs'])==o['count']
 assert all(edit(words[i],words[j])==o['distance'] for i,j in o['pairs'])
 all_pairs += [tuple(x) for x in o['pairs']]
assert len(set(all_pairs))==210
counts=[o['count'] for o in orb['pair_orbits']]
d=[F(o['distance']) for o in orb['pair_orbits']]
t=F(cert['distortion'])
wp={int(k):F(v) for k,v in cert['primal_masks_weights'].items()}
y=[F(cert['dual_constraint_multipliers'].get(str(i),'0')) for i in range(30)]
assert all(u>=0 for u in wp.values()) and all(z>=0 for z in y)
assert sum(y[15+i]*d[i] for i in range(15))==1,'dual t normalization'
assert sum(y[i]*d[i] for i in range(15))==t,'dual objective should equal t'
# cut signatures, rational feasibility of primal and nonnegative dual cost
acc=[F(0) for _ in range(15)]
seen=0
with open(P/'evidence/cuts_q4.csv') as f:
 reader=csv.reader(f);header=next(reader)
 assert len(header)==16
 for idx, r in enumerate(reader):
  mask=int(r[0]); b=[int(x) for x in r[1:]]
  assert len(b)==15
  if mask in wp:
   for k in range(15):acc[k]+=wp[mask]*F(b[k],counts[k])
  gap=sum((y[15+k]-y[k])*F(b[k],counts[k]) for k in range(15))
  assert gap>=0,('dual violated',idx,gap)
  seen+=1
assert seen==13882,(seen,'unexpected signatures count')
assert all(d[i]<=acc[i]<=t*d[i] for i in range(15)),('primal infeasible',acc)
print('PASS exact q4 upper/lower t:',t,'signatures:',seen,'pair orbits:',len(d))
print('normalized distance ratios:',[str(acc[i]/d[i]) for i in range(15)])

def universal_q(q):
 ws=[()] + [(a,) for a in range(q)] + list(itertools.product(range(q),repeat=2))
 fs=[]
 for a in range(q):
  S={(a,)};R={(a,a)};L={(a,b) for b in range(q) if a!=b};T={(b,a) for b in range(q) if a!=b}
  fs += [(R,F(1,14)),(S|L,F(1,14)),(S|T,F(1,14)),(R|L,F(3,14)),(R|T,F(3,14)),(S|R|L,F(3,14)),(S|R|T,F(3,14)),(S|R|L|T,F(1,14))]
 fs += [(set(ws)-{()},F(9,14)),({x for x in ws if len(x)==2},F(3,14)),({(a,a) for a in range(q)},F(2,14))]
 lo=F(999);hi=F(0)
 for a,b in itertools.combinations(ws,2):
  d0=edit(a,b)
  score=sum(w for C,w in fs if (a in C)!=(b in C))
  ratio=score/d0;lo=min(lo,ratio);hi=max(hi,ratio)
  assert F(1)<=ratio<=F(9,7),(q,a,b,ratio)
 return lo,hi
for q in range(1,7):
 lo,hi=universal_q(q)
 print(f'PASS explicit 9/7 cuts, q={q}, ratio range {lo}..{hi}')
print('NOTE universal q>=1 relies on exhaustion of equality patterns of <=4 letters; included in PROOF.md')
