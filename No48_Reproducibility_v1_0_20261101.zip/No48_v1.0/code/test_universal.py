from fractions import Fraction as F
import itertools

def edit(a,b):
 p=list(range(len(b)+1))
 for i,x in enumerate(a,1):
  n=[i]+[0]*len(b)
  for j,y in enumerate(b,1):n[j]=min(n[j-1]+1,p[j]+1,p[j-1]+(x!=y))
  p=n
 return p[-1]

def embed(q):
 ws=[()] + [(a,) for a in range(q)] + list(itertools.product(range(q),repeat=2))
 fs=[]
 for a in range(q):
  S={(a,)};R={(a,a)};L={(a,b) for b in range(q) if b!=a};T={(b,a) for b in range(q) if b!=a}
  fs.extend([(R,F(1,14)),(S|L,F(1,14)),(S|T,F(1,14)),(R|L,F(3,14)),(R|T,F(3,14)),(S|R|L,F(3,14)),(S|R|T,F(3,14)),(S|R|L|T,F(1,14))])
 fs.extend([(set(ws)-{()},F(9,14)),({w for w in ws if len(w)==2},F(3,14)),({(a,a) for a in range(q)},F(2,14))])
 ratios=[]
 for u,v in itertools.combinations(ws,2):
  e=edit(u,v)
  c=sum(w for cut,w in fs if ((u in cut)!=(v in cut)))
  ratios.append((c/e,u,v,c,e))
 print(q,len(ws),'min',min(x[0] for x in ratios),'max',max(x[0] for x in ratios))
 print('bad', [r for r in ratios if r[0]<1 or r[0]>F(9,7)][:5])
for q in range(1,7):embed(q)
