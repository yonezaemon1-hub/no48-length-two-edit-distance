#!/usr/bin/env python3
"""Convert the computed HiGHS basic solution into a self-contained rational certificate."""
import json, pathlib
from fractions import Fraction as F
P=pathlib.Path(__file__).resolve().parents[1]
r=json.loads((P/'evidence/q4_numerical_solution.json').read_text())
def fr(x):return F(x).limit_denominator(10**6)
weights={str(mask):str(fr(value)) for _,mask,value in r['support']}
y={str(i):str(fr(-v)) for i,v in enumerate(r['dual_marginals']) if -v>1e-8}
doc={'distortion':'123/101','primal_masks_weights':weights,'dual_constraint_multipliers':y,'dual_convention':'constraints 0..14: -A*x <= -d; constraints 15..29: A*x -d*t <=0, multipliers y>=0','note':'Every column of the cut LP corresponds to a signature in cuts_q4.csv. Primal weights are orbit-averaged cut weights. Dual variables certify all enumerated cut signatures.'}
(P/'evidence/q4_exact_certificate.json').write_text(json.dumps(doc,indent=2)+'\n')
print('PRIMAL',weights)
print('DUAL',y)
