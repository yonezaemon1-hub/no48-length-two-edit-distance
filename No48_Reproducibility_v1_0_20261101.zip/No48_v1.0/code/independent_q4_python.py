#!/usr/bin/env python3
"""Independent full Python/NumPy enumeration of q4 cut signatures.

Rebuilds words, Levenshtein distances and all S4 x reversal pair-orbits from
scratch, WITHOUT loading the bundled orbits or pairs, and enumerates all
2^20 cuts with NumPy broadcasting (independent of the C++ Gray-code enumerator).
Checks both the signature and its earliest mask against bundled cuts_q4.csv.
Requires NumPy; fail-closed if unavailable. Optional auxiliary audit only.
"""
import csv
import itertools
import pathlib
import sys

try:
    import numpy as np
except ImportError as exc:
    sys.exit('FAIL: independent Python enumeration requires NumPy: ' + str(exc))

ROOT = pathlib.Path(__file__).resolve().parents[1]
q = 4
words = [()] + [(a,) for a in range(q)] + list(itertools.product(range(q), repeat=2))
assert len(words) == 21
position = {w: i for i, w in enumerate(words)}

# Deliberately use a fresh edit-distance recursion, not any supplied distances.
def edit(a, b):
    if not a:
        return len(b)
    if not b:
        return len(a)
    return min(edit(a[1:], b) + 1, edit(a, b[1:]) + 1,
               edit(a[1:], b[1:]) + (a[0] != b[0]))

pair_to_orbit = {}
root_groups = {}
for a in range(21):
    for b in range(a+1, 21):
        orbit_images = []
        for p in itertools.permutations(range(q)):
            for backward in (False, True):
                w0 = words[a][::-1] if backward else words[a]
                w1 = words[b][::-1] if backward else words[b]
                transformed = sorted((position[tuple(p[x] for x in w0)],
                                      position[tuple(p[x] for x in w1)]))
                orbit_images.append(tuple(transformed))
        key = min(orbit_images)
        pair_to_orbit[(a,b)] = key
        root_groups.setdefault(key, []).append((a,b))

assert len(pair_to_orbit) == 210
roots = sorted(root_groups)
assert len(roots) == 15, len(roots)
for root in roots:
    assert len({edit(words[a], words[b]) for a, b in root_groups[root]}) == 1

# Compress by chunk with vectorized bit operations; each cut is independently
# evaluated from its membership bits and all 210 edges, not Gray code updates.
representatives = {}
chunk = 16384
for base in range(0, 1 << 20, chunk):
    raw = np.arange(base, min(base + chunk, 1<<20), dtype=np.uint32)
    mask = raw << np.uint32(1)  # empty word is fixed outside the cut
    signature = np.zeros((len(mask), 15), dtype=np.uint16)
    for orbit_id, root in enumerate(roots):
        for a,b in root_groups[root]:
            signature[:,orbit_id] += ((mask >> np.uint32(a)) ^ (mask >> np.uint32(b))) & np.uint32(1)
    unique_rows, first = np.unique(signature, axis=0, return_index=True)
    for values, at in zip(unique_rows, first):
        key = tuple(int(x) for x in values)
        representatives.setdefault(key, int(mask[at]))

assert len(representatives) == 13882, len(representatives)
assert representatives[(0,)*15] == 0
actual_csv = {}
with (ROOT/'evidence/cuts_q4.csv').open(newline='') as source:
    reader = csv.reader(source)
    assert next(reader) == ['mask'] + [f'b{i}' for i in range(15)]
    for row in reader:
        assert len(row) == 16
        mask = int(row[0])
        signature = tuple(map(int,row[1:]))
        assert signature not in actual_csv, ('duplicate',signature)
        actual_csv[signature] = mask
assert representatives == actual_csv, 'FAIL independent q4 Python signatures/earliest masks mismatch evidence/cuts_q4.csv'
print('PASS independently generated q4 words=21, pairs=210, pair-orbits=15')
print('PASS Python/NumPy FULL 1,048,576 cuts: exact 13,882 signatures and earliest representative masks match frozen CSV')
