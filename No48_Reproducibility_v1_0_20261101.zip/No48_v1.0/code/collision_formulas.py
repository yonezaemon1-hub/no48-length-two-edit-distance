#!/usr/bin/env python3
"""Symbolically enumerate all symbol-collision patterns for pair orbits (q=4)."""
import pathlib,json
import sympy as sp
P=pathlib.Path(__file__).resolve().parents[1]
orb=json.loads((P/'evidence/orbits_q4.json').read_text())
words=[tuple(w) for w in orb['words']]
k=sp.Symbol('k', integer=True,positive=True)
def edit(a,b):
 dp=list(range(len(b)+1))
 for i,x in enumerate(a,1):
  n=[i]+[0]*len(b)
  for j,y in enumerate(b,1):n[j]=min(n[j-1]+1,dp[j]+1,dp[j-1]+(x!=y))
  dp=n
 return dp[-1]
def partitions(r):
 if not r:return [()]
 arr=[(0,)]
 for _ in range(1,r):arr=[a+(v,) for a in arr for v in range(max(a)+2)]
 return arr
out=[]
for i,o in enumerate(orb['pair_orbits']):
 a,b=map(lambda j:words[j],o['root']); letters=sorted(set(a+b));ref={v:j for j,v in enumerate(letters)}
 aa=tuple(ref[t] for t in a);bb=tuple(ref[t] for t in b)
 r=len(letters);d=edit(aa,bb)
 numerator=0
 for pattern in partitions(r):
  blocks=max(pattern)+1 if pattern else 0
  fall=sp.prod(k-h for h in range(blocks))
  a2=tuple(pattern[x] for x in aa);b2=tuple(pattern[x] for x in bb)
  numerator+=fall*edit(a2,b2)
 E=sp.factor(numerator/k**r)
 ratio=sp.factor(E/d)
 out.append({'orbit':i,'representatives':[list(a),list(b)],'different_letters':r,'distance':d,'expected_distance':str(E),'ratio':str(ratio)})
 print(i,aa,bb,'ratio',ratio)
 assert sp.simplify(ratio-(1-1/k))>=0 if not (ratio-(1-1/k)).free_symbols else True
(P/'evidence/collision_formulas.json').write_text(json.dumps(out,indent=2)+'\n')
