#!/usr/bin/env python3
"""Fail-closed SHA256 manifest checker, pure stdlib."""
import hashlib,pathlib,sys
P=pathlib.Path(__file__).resolve().parents[1]
manifest=P/'SHA256SUMS'
if not manifest.is_file():sys.exit('FAIL: SHA256SUMS missing')
listed={}
for n,line in enumerate(manifest.read_text().splitlines(),1):
 if not line.strip():continue
 try:h,rel=line.split('  ',1)
 except ValueError:sys.exit(f'FAIL manifest format line {n}')
 if len(h)!=64 or any(x not in '0123456789abcdef' for x in h):sys.exit('FAIL bad SHA256 syntax')
 if rel in listed or '..' in pathlib.PurePosixPath(rel).parts or rel.startswith('/'):
  sys.exit('FAIL manifest duplicate/unsafe path')
 listed[rel]=h
actual={p.relative_to(P).as_posix() for p in P.rglob('*') if p.is_file() and p.name!='SHA256SUMS'}
if actual!=set(listed):
 print('FAIL extra/unlisted:',sorted(actual-set(listed)))
 print('FAIL listed/missing:',sorted(set(listed)-actual))
 sys.exit(1)
for rel,h in listed.items():
 content=(P/rel).read_bytes()
 if hashlib.sha256(content).hexdigest()!=h:sys.exit(f'FAIL hash {rel}')
print(f'PASS SHA256 exact file inventory: {len(listed)} files')
