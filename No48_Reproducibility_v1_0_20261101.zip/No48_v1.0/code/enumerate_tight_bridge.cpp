// g++ -O3 -std=c++17 code/enumerate_tight_bridge.cpp -o bridge
// ./bridge evidence/q4_slack_edges.txt evidence/q4_tight_masks.txt evidence/q5_compatible_masks.txt
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
struct Edge {int a,b,w;};
static int idx(int q, int a,int b){return 1+q+a*q+b;}
static int wordidx(int q,int len,int a=0,int b=0){if(len==0)return 0;if(len==1)return 1+a;return idx(q,a,b);}
int main(int argc,char**argv){
 if(argc!=4)return 2;
 std::vector<Edge> E;std::ifstream in(argv[1]);int a,b,w;
 while(in>>a>>b>>w)E.push_back({a,b,w});
 if(E.size()!=210)return 3;
 std::vector<uint32_t> tight;
 std::vector<uint8_t> is_tight(1u<<20,0);
 for(uint32_t mask=0;mask<(1u<<20);mask++){
  uint32_t full=mask<<1;int gap=0;
  for(auto e:E) gap+=e.w*(((full>>e.a)^(full>>e.b))&1u);
  if(gap<0){std::cerr<<"dual invalid! "<<mask<<" gap="<<gap<<"\n";return 4;}
  if(gap==0){tight.push_back(full);is_tight[mask]=1;}
 }
 std::ofstream f4(argv[2]);for(auto m:tight)f4<<m<<"\n";
 std::cerr<<"q4 tight anchored cuts = "<<tight.size()<<"\n";
 // Global q5 word numbering: empty, 5 letters, then ordered pairs.
 std::array<int,21> base{};base[0]=0;
 for(int x=0;x<4;x++)base[1+x]=1+x;
 for(int x=0;x<4;x++)for(int y=0;y<4;y++)base[idx(4,x,y)]=idx(5,x,y);
 std::array<int,10> newidx{};newidx[0]=1+4;newidx[1]=idx(5,4,4);
 for(int x=0;x<4;x++){newidx[2+2*x]=idx(5,4,x);newidx[3+2*x]=idx(5,x,4);}
 std::array<std::array<int,21>,4> proj{};
 for(int omit=0;omit<4;omit++){
  std::array<int,4> keep{};int k=0;
  for(int x=0;x<5;x++)if(x!=omit)keep[k++]=x;
  proj[omit][0]=0;
  for(int x=0;x<4;x++)proj[omit][1+x]=1+keep[x];
  for(int x=0;x<4;x++)for(int y=0;y<4;y++)proj[omit][idx(4,x,y)]=idx(5,keep[x],keep[y]);
 }
 std::ofstream f5(argv[3]);uint32_t count=0;
 for(auto m4:tight){
  uint32_t fixed=0;
  for(int j=0;j<21;j++) if((m4>>j)&1u)fixed|=(1u<<base[j]);
  for(uint32_t extras=0;extras<1024;extras++){
   uint32_t mask=fixed;
   for(int j=0;j<10;j++)if((extras>>j)&1u)mask|=(1u<<newidx[j]);
   bool ok=true;
   for(int omit=0;omit<4&&ok;omit++){
    uint32_t sub=0;
    for(int j=1;j<21;j++)if((mask>>proj[omit][j])&1u)sub|=(1u<<(j-1));
    if(!is_tight[sub])ok=false;
   }
   if(ok){f5<<mask<<"\n";count++;}
  }
 }
 std::cerr<<"q5 compatible cuts="<<count<<"\n";
 return 0;
}
