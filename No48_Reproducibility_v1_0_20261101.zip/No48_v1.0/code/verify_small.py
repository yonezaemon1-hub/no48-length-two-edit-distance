#!/usr/bin/env python3
"""Pure-stdlib verification q=2,3 cut-LP primal and dual rational certificates."""
import itertools,json,pathlib
from fractions import Fraction as F
P=pathlib.Path(__file__).resolve().parents[1]
def edit(a,b):
 dp=list(range(len(b)+1))
 for i,x in enumerate(a,1):
  n=[i]+[0]*len(b)
  for j,y in enumerate(b,1):n[j]=min(n[j-1]+1,dp[j]+1,dp[j-1]+(x!=y))
  dp=n
 return dp[-1]
for q in (2,3):
 obj=json.loads((P/f'evidence/q{q}_exact_certificate.json').read_text());w=[tuple(x) for x in obj['words']]
 pairs=list(itertools.combinations(range(len(w)),2)); d=[F(edit(w[i],w[j])) for i,j in pairs]
 m=len(pairs);t=F(obj['t'])
 primal={int(k):F(v) for k,v in obj['primal'].items()}
 y=[F(obj['dual'].get(str(i),'0')) for i in range(2*m)]
 assert all(z>=0 for z in y) and all(z>=0 for z in primal.values())
 assert sum(y[m+i]*d[i] for i in range(m))==1
 assert sum(y[i]*d[i] for i in range(m))==t
 values=[sum(weight*((((mask>>i)^(mask>>j))&1)) for mask,weight in primal.items()) for i,j in pairs]
 assert all(d[i]<=values[i]<=t*d[i] for i in range(m))
 for mask0 in range(1<<(len(w)-1)):
  mask=mask0<<1
  gap=sum((y[m+z]-y[z])*((((mask>>i)^(mask>>j))&1)) for z,(i,j) in enumerate(pairs))
  assert gap>=0,(q,mask,gap)
 print('PASS q',q,'t',t,'pairs',m,'cuts',1<<(len(w)-1))
