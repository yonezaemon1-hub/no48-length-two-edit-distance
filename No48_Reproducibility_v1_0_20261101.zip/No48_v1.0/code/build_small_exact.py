#!/usr/bin/env python3
"""Find exact q=2,3 primal/dual LP certificates using scipy for discovery."""
import itertools,json,pathlib
from fractions import Fraction as F
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix,hstack,vstack
P=pathlib.Path(__file__).resolve().parents[1]
def edit(a,b):
 dp=list(range(len(b)+1))
 for i,x in enumerate(a,1):
  n=[i]+[0]*len(b)
  for j,y in enumerate(b,1):n[j]=min(n[j-1]+1,dp[j]+1,dp[j-1]+(x!=y))
  dp=n
 return dp[-1]
for q in (2,3):
 words=[()] + [(x,) for x in range(q)] +list(itertools.product(range(q),repeat=2))
 pairs=list(itertools.combinations(range(len(words)),2))
 d=np.array([edit(words[i],words[j]) for i,j in pairs],dtype=float)
 masks=np.arange(1,1<<(len(words)-1),dtype=np.int32)
 colbits=np.array([(masks>>i)&1 for i in range(len(words)-1)],dtype=np.int8)
 bit=np.vstack([np.zeros((1,len(masks)),dtype=np.int8),colbits])
 A=np.array([bit[i]^bit[j] for i,j in pairs],dtype=float)
 n=A.shape[1]
 mat=vstack([hstack([-csr_matrix(A),csr_matrix((len(d),1))]),hstack([csr_matrix(A),csr_matrix(-d[:,None])])])
 r=linprog(np.r_[np.zeros(n),1],A_ub=mat,b_ub=np.r_[-d,np.zeros(len(d))],bounds=[(0,None)]*n+[(1,None)],method='highs')
 if not r.success:raise Exception(r.message)
 fr=lambda x:F(float(x)).limit_denominator(10**6)
 cert={'q':q,'words':[list(w) for w in words],'t':str(fr(r.fun)), 'primal':{str(int(masks[i]<<1)):str(fr(x)) for i,x in enumerate(r.x[:-1]) if x>1e-8},'dual':{str(i):str(fr(-v)) for i,v in enumerate(r.ineqlin.marginals) if v<-1e-8}}
 (P/f'evidence/q{q}_exact_certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
 print('q=',q,'t=',cert['t'],'primal',len(cert['primal']),'dual',len(cert['dual']))
