#!/usr/bin/env python3
"""Generate words/pair orbits under symbol relabeling and reversal (q=4)."""
import itertools,json,pathlib
from collections import defaultdict
P=pathlib.Path(__file__).resolve().parents[1]
q=4
words=[()] + [(i,) for i in range(q)] + [(i,j) for i in range(q) for j in range(q)]
wi={w:i for i,w in enumerate(words)}

def edit(a,b):
    dp=list(range(len(b)+1))
    for i,x in enumerate(a,1):
        nxt=[i]+[0]*len(b)
        for j,y in enumerate(b,1):
            nxt[j]=min(nxt[j-1]+1,dp[j]+1,dp[j-1]+(x!=y))
        dp=nxt
    return dp[-1]

pairs=[(i,j) for i in range(len(words)) for j in range(i+1,len(words))]
perms=list(itertools.permutations(range(q)))
roots={}
for ix,(i,j) in enumerate(pairs):
    reps=[]
    for perm in perms:
        for rev in (False,True):
            x=tuple(perm[t] for t in (words[i][::-1] if rev else words[i]))
            y=tuple(perm[t] for t in (words[j][::-1] if rev else words[j]))
            a,b=sorted((wi[x],wi[y]))
            reps.append((a,b))
    roots[(i,j)]=min(reps)
sets=defaultdict(list)
for a,b in pairs:sets[roots[(a,b)]].append((a,b))
orbits=sorted(sets)
assert len(orbits)==15,len(orbits)
for root in orbits: assert len({edit(words[a],words[b]) for a,b in sets[root]})==1
out={'q':q,'words':[list(w) for w in words], 'pair_orbits':[{'root':list(root),'pairs':[list(p) for p in sets[root]],'count':len(sets[root]),'distance':edit(words[root[0]],words[root[1]])} for root in orbits]}
(P/'evidence'/'orbits_q4.json').write_text(json.dumps(out,indent=2)+'\n')
print('words',len(words),'pairs',len(pairs),'pair_orbits',len(orbits),'counts',[len(sets[r]) for r in orbits])
