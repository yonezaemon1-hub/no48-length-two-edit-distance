#!/usr/bin/env python3
"""Independent exact-rational review of 5-letter cut weights and theorem algebra.
The 58,720,256-case exhaustive check requires compiled audit_q5_ST.cpp.
"""
import itertools,json,math,pathlib,random
from collections import defaultdict
from fractions import Fraction as F
P=pathlib.Path(__file__).resolve().parents[1]
o4=json.loads((P/'evidence/orbits_q4.json').read_text())
o5=json.loads((P/'evidence/q5_orbits.json').read_text())
c4=json.loads((P/'evidence/q4_exact_certificate.json').read_text())
c5=json.loads((P/'evidence/q5_restricted_lp.json').read_text())
d4=[F(o['distance']) for o in o4['pair_orbits']]
d5=[F(o['distance']) for o in o5['pair_orbits']]
y4=[F(c4['dual_constraint_multipliers'].get(str(i),'0')) for i in range(30)]
y5=[F(c5['dual'].get(str(i),'0')) for i in range(30)]
assert all(v>=0 for v in y4+y5)
assert sum(y4[15+i]*d4[i] for i in range(15))==1
assert sum(y4[i]*d4[i] for i in range(15))==F(123,101)
assert sum(y5[15+i]*d5[i] for i in range(15))==1
assert sum(y5[i]*d5[i] for i in range(15))==F(47,37)
words4=[tuple(w) for w in o4['words']]
words5=[tuple(w) for w in o5['words']]
idx5={w:i for i,w in enumerate(words5)}
S=defaultdict(F);T=defaultdict(F)
for ss in itertools.combinations(range(5),4):
 tr={i:idx5[tuple(ss[x] for x in w)] for i,w in enumerate(words4)}
 for i,orb in enumerate(o4['pair_orbits']):
  coef=(y4[i+15]-y4[i])/F(orb['count'])
  for a,b in orb['pairs']:
   key=tuple(sorted([tr[a],tr[b]]))
   S[key]+=coef
for i,orb in enumerate(o5['pair_orbits']):
 coef=(y5[i+15]-y5[i])/F(orb['count'])
 for a,b in orb['pairs']:T[a,b]+=coef
# The 56 canonical bit-state classes in audit_q5_ST.cpp are valid only if
# BOTH signed edge functionals are invariant under S5 x word reversal.
# Check the action directly on all 465 unordered edges, for all 120*2 maps.
index5={w:i for i,w in enumerate(words5)}
edge_values={(a,b):(S[a,b],T[a,b]) for a in range(len(words5))
             for b in range(a+1,len(words5))}
assert len(edge_values)==465
checked_actions=0
for perm in itertools.permutations(range(5)):
 for reverse in (False,True):
  mapped=[]
  for w in words5:
   z=tuple(perm[x] for x in (w[::-1] if reverse else w))
   mapped.append(index5[z])
  assert len(set(mapped))==31
  for (a,b),pair_weights in edge_values.items():
   key=tuple(sorted((mapped[a],mapped[b])))
   assert edge_values[key]==pair_weights,(
     'S/T symmetry violation',perm,reverse,a,b,key,
     pair_weights,edge_values[key])
  checked_actions+=1
assert checked_actions==240
print('PASS q5 S,T invariance under all 120 alphabet permutations x 2 reversals: 465 edges per action')
edges=[]
for line in (P/'evidence/q5_ST_edges.txt').read_text().splitlines():
 a,b,s,t=map(int,line.split());edges.append((a,b,s,t))
assert len(edges)==465
scale=math.lcm(*[x.denominator for x in S.values()],*[x.denominator for x in T.values()])
assert scale==896880
for a,b,s,t in edges:
 assert S[a,b]*scale==s and T[a,b]*scale==t
for mask in [0,1<<1,43049020,0b1010110100101001000101001010110]:
 s=sum(z*((((mask>>a)^(mask>>b))&1)) for a,b,z,_ in edges)
 t=sum(z*((((mask>>a)^(mask>>b))&1)) for a,b,_,z in edges)
 assert 606*s+185*t>=0,(mask,s,t)
scan={}
for line in (P/'evidence/q5_ST_scan.txt').read_text().splitlines():
 key,v=line.split('=',1);scan[key]=v
assert int(scan['checked'])==56*2**20
assert int(scan['min_606S_plus_185T'])==0 and int(scan['negative_606S_plus_185T'])==0
mask=int(scan['mask_at_max_ratio'])
s=sum(z*((((mask>>a)^(mask>>b))&1)) for a,b,z,_ in edges)
t=sum(z*((((mask>>a)^(mask>>b))&1)) for a,b,_,z in edges)
assert F(-t,s)==F(606,185)
assert F(s,-t)==F(185,606)
# If a noncontracting l1 embedding has expansion t*, each of 5 q4-dual scores is at most t*-123/101;
# q5 T dual score is at most t*-47/37. The validated cut inequality implies:
# 0 <= 606*5*(t*-123/101)+185*(t*-47/37).
lower=(606*5*F(123,101)+185*F(47,37))/(606*5+185)
assert lower==F(785,643)
assert lower>F(123,101)
print('PASS exact rational coefficient reconstruction of 465 q5 edges (scale',scale,')')
print('PASS dual normalizations, optimal-ratio witness and theorem algebra: q>=5 lower=',lower)
print('IMPORTANT full-cut exhaustiveness is checked only by compiling/running audit_q5_ST.cpp.')
