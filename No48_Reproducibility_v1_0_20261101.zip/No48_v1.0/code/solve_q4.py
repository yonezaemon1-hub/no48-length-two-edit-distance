#!/usr/bin/env python3
"""Symmetric cut-cone LP, with exact rational certificate construction and verification."""
import json,csv, pathlib
from fractions import Fraction as F
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import hstack, vstack, csr_matrix
P=pathlib.Path(__file__).resolve().parents[1]
orb=json.loads((P/'evidence/orbits_q4.json').read_text())['pair_orbits']
counts=np.array([o['count'] for o in orb],dtype=float)
dists=np.array([o['distance'] for o in orb],dtype=float)
rows=list(csv.reader(open(P/'evidence/cuts_q4.csv')))[1:]
masks=np.array([int(r[0]) for r in rows],dtype=np.int64)
B=np.array([[int(x) for x in r[1:]] for r in rows],dtype=np.int16).T
A=(B/counts[:,None]).astype(float)
n=A.shape[1]
# min t subject to -A w <= -d, A w <= d*t
mat=vstack([hstack([-csr_matrix(A), csr_matrix((15,1))]),hstack([csr_matrix(A), csr_matrix(-dists[:,None])])]).tocsr()
c=np.r_[np.zeros(n),1.0]
r=linprog(c,A_ub=mat,b_ub=np.r_[-dists,np.zeros(15)],bounds=[(0,None)]*n+[(1,None)],method='highs',options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
print('LP',r.success,r.message,r.fun,'support',np.sum(r.x[:-1]>1e-8) if r.success else None)
if not r.success:raise SystemExit(1)
# support for each orbit representative column
supports=[(int(i),int(masks[i]),float(r.x[i])) for i in np.where(r.x[:-1]>1e-8)[0]]
print('SUPPORT',supports)
print('DUAL NONZERO',[(i,v) for i,v in enumerate(r.ineqlin.marginals) if abs(v)>1e-8])
(P/'evidence/q4_numerical_solution.json').write_text(json.dumps({'optimal_distortion_float':r.fun,'support':supports,'dual_marginals':r.ineqlin.marginals.tolist(),'pair_orbit_counts':counts.astype(int).tolist(),'pair_orbit_distances':dists.astype(int).tolist()},indent=2)+'\n')
