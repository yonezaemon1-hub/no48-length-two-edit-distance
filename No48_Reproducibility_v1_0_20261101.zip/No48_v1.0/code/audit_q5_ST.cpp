// Check cut inequalities on all 56*2^20 canonical classes of 5-letter cuts.
// g++ -O3 -std=c++17 code/audit_q5_ST.cpp -o audit_q5_ST
// ./audit_q5_ST evidence/q5_ST_edges.txt evidence/q5_ST_scan.txt
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <numeric>
#include <vector>
static constexpr int N=31;
using ll=long long;
int main(int argc,char **argv){
 if(argc!=3)return 2;
 ll WS[N][N]={},WT[N][N]={};
 std::ifstream f(argv[1]);int a,b;ll s,t;int read=0;
 while(f>>a>>b>>s>>t){ WS[a][b]=WS[b][a]=s;WT[a][b]=WT[b][a]=t;read++;}
 if(read!=465){std::cerr<<"bad edges count "<<read<<"\n";return 3;}
 std::vector<int> mixed;for(int x=0;x<5;x++)for(int y=0;y<5;y++)if(x!=y)mixed.push_back(6+5*x+y);
 if(mixed.size()!=20)return 4;
 uint64_t samples=0;ll bestNegT=0,bestS=1;uint32_t bestMask=0;
 ll minS=1LL<<60,minTarget=1LL<<60;uint32_t minTargetMask=0;ll minT=1LL<<60; uint64_t negativeTarget=0,negativeS=0;
 int block=0;
 for(int v0=0;v0<=3;v0++)for(int v1=v0;v1<=3;v1++)for(int v2=v1;v2<=3;v2++)for(int v3=v2;v3<=3;v3++)for(int v4=v3;v4<=3;v4++){
  const int vals[5]={v0,v1,v2,v3,v4};
  uint32_t mask=0;
  for(int x=0;x<5;x++){
   if(vals[x]&1) mask|=1u<<(1+x);
   if(vals[x]&2) mask|=1u<<(6+5*x+x);
  }
  int sign[N];for(int j=0;j<N;j++)sign[j]=((mask>>j)&1u)?-1:1;
  ll fieldS[N]={},fieldT[N]={};
  for(int j=0;j<N;j++)for(int k=0;k<N;k++){
   fieldS[j]+=WS[j][k]*sign[k];fieldT[j]+=WT[j][k]*sign[k];
  }
  ll curS=0,curT=0;
  for(int j=0;j<N;j++)for(int k=j+1;k<N;k++)if(sign[j]!=sign[k]){
   curS+=WS[j][k];curT+=WT[j][k];
  }
  for(uint32_t step=0;step<(1u<<20);step++){
   samples++;
   // Cross-check incremental Gray-code arithmetic against direct edge summation.
   if((step & 65535u)==0u){
     ll bruteS=0, bruteT=0;
     for(int x=0;x<N;x++)for(int y=x+1;y<N;y++)if(((mask>>x)^(mask>>y))&1u){bruteS+=WS[x][y];bruteT+=WT[x][y];}
     assert(bruteS==curS && bruteT==curT);
   }
   if(curS<minS)minS=curS;
   if(curT<minT)minT=curT;
   ll target=606*curS+185*curT;
   if(target<minTarget){minTarget=target;minTargetMask=mask;}
   if(curS<0)negativeS++;
   if(target<0)negativeTarget++;
   if(curS>0&&curT<0){
    ll nt=-curT;
    if((__int128)nt*bestS>(__int128)bestNegT*curS){bestNegT=nt;bestS=curS;bestMask=mask;}
   }
   if(step+1==(1u<<20))break;
   int j=mixed[__builtin_ctz(step+1)];
   int old=sign[j];
   curS += old*fieldS[j];curT += old*fieldT[j];
   for(int k=0;k<N;k++){fieldS[k]+=-2*old*WS[k][j];fieldT[k]+=-2*old*WT[k][j];}
   sign[j]=-old;
   mask^=(1u<<j);
  }
  block++;if(block%14==0)std::cerr<<"finished "<<block<<"/56 states\n";
 }
 std::ofstream o(argv[2]);
 o<<"checked="<<samples<<"\nmin_S="<<minS<<"\nmin_T="<<minT<<"\nmin_606S_plus_185T="<<minTarget<<"\nnegative_S="<<negativeS<<"\nnegative_606S_plus_185T="<<negativeTarget<<"\nmax_negative_T_over_S="<<bestNegT<<"/"<<bestS<<"\nmask_at_max_ratio="<<bestMask<<"\nmask_at_min_606S_plus_185T="<<minTargetMask<<"\n";
 std::cerr<<"done "<<samples<<" min 606S+185T="<<minTarget<<" max(-T/S)="<<bestNegT<<"/"<<bestS<<"\n";
 return (negativeS||negativeTarget)?5:0;
}
