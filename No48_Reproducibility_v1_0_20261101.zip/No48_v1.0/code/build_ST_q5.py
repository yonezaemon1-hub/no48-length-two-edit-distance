#!/usr/bin/env python3
"""Create exact signed edge matrices for q5 dual S and restricted dual T."""
import json,itertools,math,pathlib
from fractions import Fraction as F
from collections import defaultdict
P=pathlib.Path(__file__).resolve().parents[1]
c4=json.loads((P/'evidence/q4_exact_certificate.json').read_text())
c5=json.loads((P/'evidence/q5_restricted_lp.json').read_text())
o4=json.loads((P/'evidence/orbits_q4.json').read_text())
o5=json.loads((P/'evidence/q5_orbits.json').read_text())
y4=[F(c4['dual_constraint_multipliers'].get(str(i),'0')) for i in range(30)]
y5=[F(c5['dual'].get(str(i),'0')) for i in range(30)]
edgeS=defaultdict(F);edgeT=defaultdict(F)
ws4=[tuple(w) for w in o4['words']]
ws5=[tuple(w) for w in o5['words']]; w5idx={w:i for i,w in enumerate(ws5)}
for subset in itertools.combinations(range(5),4):
 trans={i:w5idx[tuple(subset[x] for x in word)] for i,word in enumerate(ws4)}
 for i,o in enumerate(o4['pair_orbits']):
  coeff=(y4[15+i]-y4[i])/o['count']
  for a,b in o['pairs']:
   ia,ib=sorted((trans[a],trans[b]));edgeS[ia,ib]+=coeff
for i,o in enumerate(o5['pair_orbits']):
 coeff=(y5[15+i]-y5[i])/o['count']
 for a,b in o['pairs']:edgeT[a,b]+=coeff
lcm=math.lcm(*(x.denominator for x in edgeS.values()),*(x.denominator for x in edgeT.values()))
assert lcm<1e12
with open(P/'evidence/q5_ST_edges.txt','w') as f:
 for a in range(31):
  for b in range(a+1,31):
   f.write(f'{a} {b} {int(edgeS[a,b]*lcm)} {int(edgeT[a,b]*lcm)}\n')
print('lcm',lcm,'S max',max(abs(x*lcm) for x in edgeS.values()),'T max',max(abs(x*lcm) for x in edgeT.values()))
Svals=[];Tvals=[]
for l in (P/'evidence/q5_compatible_masks.txt').read_text().splitlines():
 m=int(l)
 S=sum(v*(((m>>a)^(m>>b))&1) for (a,b),v in edgeS.items())
 T=sum(v*(((m>>a)^(m>>b))&1) for (a,b),v in edgeT.items())
 Svals.append(S);Tvals.append(T)
print('on compatible masks: S range',min(Svals),max(Svals),'T range',min(Tvals),max(Tvals),'distinct T',len(set(Tvals)))
print('T minimum',min(Tvals))
