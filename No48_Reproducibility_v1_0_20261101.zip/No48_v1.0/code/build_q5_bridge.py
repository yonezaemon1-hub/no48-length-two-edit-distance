#!/usr/bin/env python3
"""Build exact integer edge coefficients for the q4 optimal dual cut slack."""
import json, pathlib, math
from fractions import Fraction as F
P=pathlib.Path(__file__).resolve().parents[1]
c=json.loads((P/'evidence/q4_exact_certificate.json').read_text())
O=json.loads((P/'evidence/orbits_q4.json').read_text())['pair_orbits']
y=[F(c['dual_constraint_multipliers'].get(str(i),'0')) for i in range(30)]
coefs=[(y[i+15]-y[i])/len(O[i]['pairs']) for i in range(15)]
lcm=math.lcm(*(x.denominator for x in coefs))
with open(P/'evidence/q4_slack_edges.txt','w') as f:
 for i,o in enumerate(O):
  for a,b in o['pairs']:
   z=int(coefs[i]*lcm)
   f.write(f'{a} {b} {z}\n')
print('scale',lcm,'coeff', [str(c) for c in coefs])
