# No.48 — Proof-audit notes and trust boundary (v0.2)

## Objects

- Unit-cost insert/delete/substitute Levenshtein distance, **including empty word**.
- ℓ1 finite metric = nonnegative sum of cut semimetrics.
- Normalize embedding so every embedded distance is at least the edit distance.
- Each alphabet relabeling and word reversal acts by edit-distance isometries.
- q=4 word order: empty, 4 one-letter words, 16 ordered two-letter words.
- q=5 word order: empty, 5 one-letter words, 25 ordered two-letter words.

## q≤4: exact primal/dual LP certificates

For pair orbit i, let N_i be its number of unordered pairs, d_i their (common) edit distance, and b_i(C) the number separated by cut C. The group-averaged cut has coefficient a_i(C)=b_i(C)/N_i.

The primal LP has variables w_C≥0 and t≥1, and imposes

    d_i ≤ sum_C w_C a_i(C) ≤ t*d_i   (all pair orbits i).

The dual multipliers in the JSON certificates are indexed 0..m−1 for the lower constraints `−A*w≤−d` and m..2m−1 for the upper constraints `A*w−d*t≤0` (m=15 for q4, m=#pairs for q2,3). The exact verifier checks:

- positive multiplier and primal weights;
- upper dual normalization sum_i(y_upper_i*d_i)=1;
- lower dual objective sum_i(y_lower_i*d_i)=t;
- dual cut inequalities sum_i(y_upper_i−y_lower_i)*a_i(C)≥0 for **every** column;
- primal inequalities for all pairs/orbits.

Thus weak duality plus the feasible construction establishes the optimum *exactly*, not as a floating-point estimate.

For q4 there are 2^20 cuts with empty bit fixed to zero, collapsing to 13,882 signatures, including zero. The C++ enumerator produces `cuts_q4.csv` with stable mask ordering; the pure-Python verifier checks all signatures using Fraction.

## q=5: fully specified lower-bound certificate

The q4 exact dual is reused on each 4-element subset of the 5-letter alphabet, producing a signed sum S. A second signed pair-orbit linear form T is given by the explicitly recorded coefficients in `q5_restricted_lp.json` and repeated below:

- q5 T lower pair orbits: orbit 4→10/37, orbit 7→27/74, orbit 9→5/37.
- q5 T upper pair orbits: orbit 5→47/74, orbit 11→27/74.

The orbit numbering is entirely defined by `evidence/q5_orbits.json` (both word-pair members and pair edit distances are supplied). `code/verify_q5_certificate.py` independently reconstructs all 465 undirected edge coefficients of S and T, checks that they agree with `q5_ST_edges.txt`, and checks exact normalization and the resulting bound.

Write c_S(C)=sum_{pairs (u,v)} s_{uv} δ_C(u,v), and similarly for c_T. Coefficients in the text file are exactly 896880*s_{uv} and 896880*t_{uv}. The exhaustive C++ checker tests:

    606 c_S(C)+185 c_T(C) ≥ 0

for every cut up to complement and alphabet relabeling.

The Python verifier now checks all 240 group actions (120 alphabet relabelings times two global word-reversal choices) against all 465 signed edge coefficients for BOTH S and T, and fails closed if either is not invariant. This is essential for the 56-state reduction.

The 56 canonical single/repeated-bit assignments are the sorted length-5 multisets of 4 possible two-bit symbols (there are binom(8,3)=56). The remaining 20 bits for all mixed words are enumerated freely. For each canonical class and all 2^20 possibilities, the checker computes S,T incrementally; every 65536 steps it recomputes the whole cut from its 465 edges and asserts equality.

The **upper bound on the expression** for a distortion-t embedding follows explicitly: for each 4-letter subset A, the nonnegative dual weights give S_A = sum(y_upper * x) - sum(y_lower * x) <= t sum(y_upper * d) - sum(y_lower * d) = t-123/101. Summing over all five subsets gives S<=5(t-123/101). The same normalization gives T<=t-47/37. Hence the upper bound is

    606*5*(t−123/101) +185*(t−47/37).

Since the tested signed cut inequality is nonnegative on each cut, and ℓ1 distances decompose into nonnegative cuts, this upper bound must be nonnegative. Solving gives

    t≥(3030*(123/101)+185*(47/37))/3215 = 785/643.

`q5_ST_scan.txt` records a cut at which the ratio -T/S is 606/185, confirming the coefficient 185/606 is sharp **within this two-functional combination**. It does not show the bound is optimal among all possible duals.

## Universality of the 9/7 construction

The eight per-letter cut families and three global cuts in the draft depend only on the equality pattern of the at most four letters appearing in a word pair. A letter absent from both words contributes zero to every letter-specific cut. Therefore a check of all ordered word pairs over a four-letter alphabet proves the same estimate for every larger alphabet. `verify_exact.py` checks q=1..6 exhaustively as an independent guard against errors in this reasoning.

## Convergence-to-infinite-alphabet claim

In this section D_infinity is defined as sup_{q>=1} D_q(2), with maximum word length fixed at two.

`collision_formulas.json` contains the exact expectations for each pair orbit, computed using set-partition collision patterns. For a partition into b image-color blocks among r distinct original letters, the probability is (k)_b / k^r. The four distinct contraction ratios are 1, 1−1/k, 1−1/(2k), 1−1/k+1/(2k²). Hence averaging the pullback of the optimal finite-k embedding yields D_∞≤[k/(k−1)]D_k.

## What a verifier does *not* establish

- This is a **computer-assisted proof**, not a fully formalized Lean/Coq proof.
- Test output alone is not a replacement for review of the C++ enumeration logic and the finite-cut reduction.
- The novelty and correctness of the OpenAI reference are independent issues.
- The exact D_5 and D_∞ values remain open in this manuscript.
- The stronger 457/367 bound is not reconstructed in this package.
- No third-party or human peer review has been performed.
