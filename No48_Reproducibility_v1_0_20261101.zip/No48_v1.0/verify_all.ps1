# PowerShell 5.1 compatible. Run: powershell -ExecutionPolicy Bypass -File .\verify_all.ps1
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$python = Get-Command python -ErrorAction SilentlyContinue
$compiler = Get-Command g++ -ErrorAction SilentlyContinue
if ($null -eq $python) { throw 'FAIL: Python 3 required.' }
if ($null -eq $compiler) { throw 'FAIL: g++ (C++17) required for complete audit.' }
$temporary = Join-Path ([IO.Path]::GetTempPath()) ('No48_AUDIT_' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $temporary | Out-Null
function RunChecked([string]$exe,[string[]]$argv) {
    & $exe @argv
    if ($LASTEXITCODE -ne 0) { throw ('FAIL execution: ' + $exe + ' ' + ($argv -join ' ')) }
}
function CompareFiles([string]$a,[string]$b) {
    $ha=(Get-FileHash -LiteralPath $a -Algorithm SHA256).Hash
    $hb=(Get-FileHash -LiteralPath $b -Algorithm SHA256).Hash
    if ($ha -ne $hb) { throw ('FAIL mismatching files: ' + $a + ' / ' + $b) }
}
try {
    RunChecked 'python' @('-I','code/verify_hashes.py')
    RunChecked 'python' @('-I','code/verify_small.py')
    RunChecked 'python' @('-I','code/verify_exact.py')
    RunChecked 'python' @('-I','code/verify_q5_certificate.py')
    $cuts=Join-Path $temporary 'cuts.exe';$bridge=Join-Path $temporary 'bridge.exe';$scan=Join-Path $temporary 'scan.exe'
    RunChecked 'g++' @('-O3','-std=c++17','code/enumerate_cuts.cpp','-o',$cuts)
    RunChecked 'g++' @('-O3','-std=c++17','code/enumerate_tight_bridge.cpp','-o',$bridge)
    RunChecked 'g++' @('-O3','-std=c++17','code/audit_q5_ST.cpp','-o',$scan)
    $tmpCsv=Join-Path $temporary 'cuts_q4.csv'
    RunChecked $cuts @('evidence/pairs_q4.txt',$tmpCsv)
    CompareFiles 'evidence/cuts_q4.csv' $tmpCsv
    $tmpTight=Join-Path $temporary 'q4_tight_masks.txt'
    $tmpComp=Join-Path $temporary 'q5_compatible_masks.txt'
    RunChecked $bridge @('evidence/q4_slack_edges.txt',$tmpTight,$tmpComp)
    CompareFiles 'evidence/q4_tight_masks.txt' $tmpTight
    CompareFiles 'evidence/q5_compatible_masks.txt' $tmpComp
    $tmpScan=Join-Path $temporary 'q5_ST_scan.txt'
    RunChecked $scan @('evidence/q5_ST_edges.txt',$tmpScan)
    CompareFiles 'evidence/q5_ST_scan.txt' $tmpScan
    Write-Output 'PASS COMPLETE: SHA256, exact q2-4 LP, q5 58,720,256 integer cases.'
} finally {
    if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force -Recurse }
}
