# No.48 v1.0 公開版

著者：Ryutaro Yonezu - Independent Researcher。2026-11-01。

中心定理：D_4(2)=123/101、全q>=5でD_q(2)>=785/643。空語を含む長さ2以下・単位コスト挿入/削除/置換・実l1への最小歪み。q>=5や無限文字種の一般最適値は未決定。

計算機支援証明。独立AI監査PASSを継承し、公開用に既存検証器・全数検査・独立Python q4列挙を再実行。新規性INCONCLUSIVE、人間査読未実施、All rights reserved。

Andoniほか（2003）の有限文字列カットLPと二進長さ3以下の4/3は既知研究。OpenAI No.099は最大文字列長の漸近問題。本論文は長さ2固定の文字種依存性。数学部分・コード・証明書はv0.2から変更なし。

再現手順と権利・監査の詳細はREADME.md、英文論文Section 7、STATUS_AND_LIMITS.mdを参照。過去のAUDIT_RUN、DELTA、PRIOR_ART_PASS2、PROOF_AUDIT内のHOLDは履歴として保存。現在の公開版の状態はv1.0の文書に従う。
