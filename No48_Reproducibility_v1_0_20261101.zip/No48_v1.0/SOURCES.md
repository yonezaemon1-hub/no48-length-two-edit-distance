# Sources and attribution - v1.0

See PAPER_EN.md Section 7 and References for the release's bibliographic comparison.

- Andoni, Deza, Gupta, Indyk, Raskhodnikova (2003), SODA, pp. 523-526, DOI 10.1145/644108.644196. Author-hosted PDF: https://cs-people.bu.edu/sofya/pubs/embedding-of-edit-distance.pdf. All four PDF pages were visually inspected on 2026-11-01. Existing finite-string cut-LP method and binary length<=3 distortion 4/3 explicitly acknowledged.
- OpenAI Math family 099: https://github.com/openai/math/blob/main/lean/docs/099.md. Scope inspected on 2026-11-01. Large-length asymptotics and selected Lean statements distinguished from length-two finite certificates. No claim to have replayed the OpenAI formalization.
- OpenAI companion preprint: https://github.com/openai/math/tree/main/preprints/Edit-Distance-in-l1-Matching-Bounds-up-to-Constants-in-the-Exponent-September-27-2026.
- Deza and Laurent, Geometry of Cuts and Metrics (1997), DOI 10.1007/978-3-642-04295-9. Established cut-cone background.

PRIOR_ART_PASS2.md is retained as a historical partial search report. It does not supersede the corrected Andoni attribution. No exhaustive priority search or novelty clearance is claimed. Novelty: INCONCLUSIVE.
