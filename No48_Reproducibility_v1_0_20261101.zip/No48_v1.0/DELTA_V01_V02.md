# No.48 v0.2 — Audit-response change log

Date: 2026-11-01. This is a *difference-only* revision to v0.1; the theorem statements, frozen cut evidence, LP certificates, and test data are not modified.

| Auditor item | v0.2 corrective action | Result |
|---|---|---|
| 1. S,T invariance not checked by verification script | Add exact all-edge test for 120 alphabet permutations × 2 global word reversals to `code/verify_q5_certificate.py` | PASS: 240 actions × 465 edges |
| 2. Missing derivation of S≤5(t−123/101) | Add explicit nonnegative dual-weight argument for each four-letter restriction and sum over 5 subsets in §4 of `PAPER_DRAFT_EN.md` | Text fixed |
| 3. Definition of D_infinity should be explicit | Define D_infinity=sup_{q>=1}D_q(2) with maximum word length fixed at two in Theorem 4 and audit notes | Text fixed |
| 4. Frozen C++ enumeration output compared only to rerun | Add `code/independent_q4_python.py` to derive words, edit distances, pair orbits, and all 2^20 cut signatures independently from scratch (NumPy required) | PASS: exactly 13,882 signature+earliest-mask rows |
| Prior-art Pass 2 | `PRIOR_ART_PASS2.md` compares 5 source families and enumerates gaps; `SOURCES.md` extended | REFERENCES PARTIAL, NOVELTY INCONCLUSIVE |

Both primary Python and C++ full verification scripts still run without third-party Python dependencies. The **optional** independent Python/NumPy enumeration is supplementary and intentionally separated from the primary one-shot verifiers. The user-supplied independent 2^30 brute-force scan is recorded as a reported external audit, but has not been replicated inside this package.

No mathematics was strengthened. The confirmed lower bound remains D_q(2)>=785/643 for q>=5; the upper bound retained is 9/7. Earlier unreplicated stronger upper bounds remain excluded. RELEASE HOLD.
