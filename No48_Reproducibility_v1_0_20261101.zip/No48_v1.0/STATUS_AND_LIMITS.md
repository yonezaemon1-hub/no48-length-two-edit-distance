# No.48 v1.0 - Status and claim limits

Date: 2026-11-01. Proof: Computer-assisted proof. License: All rights reserved.

| Item | Release status |
|---|---|
| D_4(2)=123/101 | PASS: matching exact primal/dual certificates |
| D_q(2)>=785/643 for q>=5 | PASS: finite integer cut inequality and exhaustive scan |
| D_5(2)>D_4(2) | Consequence of the two preceding certified bounds |
| All mathematical sections 1-6 / code / frozen evidence | Unchanged from v0.2; SHA256 comparisons supplied |
| Existing verification and independent q4 Python enumeration | Rerun for v1.0; see PUBLICATION_CHECKS.json and logs |
| Independent AI audit | Reported PASS in the supplied v0.2 audit; scope detailed in paper Section 7 |
| Human peer review | Not human peer-reviewed |
| Full formalization | Not a Lean/Coq formal proof |
| Novelty / priority | INCONCLUSIVE |
| Exact D_5(2), D_infinity(2), general q>=5 optimum | Not determined |
| Stronger exploratory bounds | Not adopted without complete frozen certificates |

Andoni et al. (2003) already study finite strings via cut-LP; their binary length<=3 distortion 4/3 is prior work. OpenAI No.099 addresses growing maximum string length with uniform alphabet constants. This release fixes length<=2 and varies alphabet size; no asymptotic improvement or general-optimum claim is made.

Historical files preserved from v0.2 reflect their original preparation date and HOLD status. The v1.0 manuscript/README govern the publication scope. User authorization on 2026-11-01 permits formal preprint publication with novelty INCONCLUSIVE and no human peer review.
